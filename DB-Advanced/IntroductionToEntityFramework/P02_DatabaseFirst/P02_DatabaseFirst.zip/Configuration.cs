﻿
namespace P02_DatabaseFirst
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-32FEOB6\SQLEXPRESS;Database=SoftUni;Integrated Security=True;";
    }
}
