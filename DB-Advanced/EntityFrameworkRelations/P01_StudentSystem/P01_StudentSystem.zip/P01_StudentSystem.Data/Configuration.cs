﻿namespace P01_StudentSystem.Data
{
    internal static class Configuration
    {
        public static string ConnectionString { get; set; } 
            = @"Server=DESKTOP-32FEOB6\SQLEXPRESS;Database=Student System;Integrated Security=True";
    }
}