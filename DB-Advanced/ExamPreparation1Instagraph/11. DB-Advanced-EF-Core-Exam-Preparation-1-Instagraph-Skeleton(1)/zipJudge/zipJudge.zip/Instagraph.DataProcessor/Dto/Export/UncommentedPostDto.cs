﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Instagraph.DataProcessor.Dto.Export
{
    public class UncommentedPostDto
    {
        public int Id { get; set; }

        public string Picture { get; set; }

        public string User { get; set; }
    }
}
