﻿namespace Instagraph.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => @"Server=DESKTOP-32FEOB6\SQLEXPRESS;Database=Instagraph;Integrated Security=True;";
    }
}
