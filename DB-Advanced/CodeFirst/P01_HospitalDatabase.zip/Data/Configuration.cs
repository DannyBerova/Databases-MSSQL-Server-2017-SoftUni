﻿namespace P01_HospitalDatabase.Data
{
    using System;

    public static class Configuration
    {
        public static string ConnectionString { get; set; } = @"Server=DESKTOP-32FEOB6\SQLEXPRESS;Database=Hospital;Integrated Security=True";
    }
}
